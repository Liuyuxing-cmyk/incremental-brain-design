import fs from 'fs';
import path from 'path';

// Types
export interface Collection {
  id: string;
  name: string;
  description?: string;
  coverImage: string;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface WorkImage {
  id: string;
  collectionId: string;
  fileName: string;
  originalName: string;
  themeName: string;
  filePath: string;
  sortOrder: number;
  createdAt: string;
}

export interface SiteConfig {
  title: string;
  slogan: string;
  adminPassword: string;
}

export interface SiteData {
  config: SiteConfig;
  collections: Collection[];
  images: WorkImage[];
}

// File paths
const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'site-data.json');
const UPLOADS_DIR = path.join(process.cwd(), 'public', 'uploads');

// Ensure directories exist
function ensureDirectories() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

// Read data from JSON file
export function readData(): SiteData {
  ensureDirectories();
  
  if (!fs.existsSync(DATA_FILE)) {
    const defaultData: SiteData = {
      config: {
        title: '增量大脑设计部',
        slogan: '用设计驱动增长，以作品证明实力',
        adminPassword: '$2a$10$KBdGxHqQqK8pV6YJQn5yKuJCv5p7Qf5w5K5H5J5K5J5K5H5J5K5H'
      },
      collections: [],
      images: []
    };
    writeData(defaultData);
    return defaultData;
  }
  
  const content = fs.readFileSync(DATA_FILE, 'utf-8');
  return JSON.parse(content);
}

// Write data to JSON file
export function writeData(data: SiteData): void {
  ensureDirectories();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Collection operations
export function getCollections(): Collection[] {
  const data = readData();
  return data.collections.sort((a, b) => a.sortOrder - b.sortOrder);
}

export function getCollectionById(id: string): Collection | undefined {
  const data = readData();
  return data.collections.find(c => c.id === id);
}

export function createCollection(collection: Omit<Collection, 'createdAt' | 'updatedAt'>): Collection {
  const data = readData();
  const now = new Date().toISOString();
  const newCollection: Collection = {
    ...collection,
    createdAt: now,
    updatedAt: now
  };
  data.collections.push(newCollection);
  writeData(data);
  return newCollection;
}

export function updateCollection(id: string, updates: Partial<Collection>): Collection | null {
  const data = readData();
  const index = data.collections.findIndex(c => c.id === id);
  if (index === -1) return null;
  
  data.collections[index] = {
    ...data.collections[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  writeData(data);
  return data.collections[index];
}

export function deleteCollection(id: string): boolean {
  const data = readData();
  const initialLength = data.collections.length;
  data.collections = data.collections.filter(c => c.id !== id);
  
  // Also delete associated images
  data.images = data.images.filter(img => img.collectionId !== id);
  
  if (data.collections.length < initialLength) {
    writeData(data);
    return true;
  }
  return false;
}

// Image operations
export function getImages(collectionId?: string): WorkImage[] {
  const data = readData();
  let images = data.images;
  
  if (collectionId) {
    images = images.filter(img => img.collectionId === collectionId);
  }
  
  return images.sort((a, b) => a.sortOrder - b.sortOrder);
}

export function getImageById(id: string): WorkImage | undefined {
  const data = readData();
  return data.images.find(img => img.id === id);
}

export function createImage(image: Omit<WorkImage, 'createdAt'>): WorkImage {
  const data = readData();
  const newImage: WorkImage = {
    ...image,
    createdAt: new Date().toISOString()
  };
  data.images.push(newImage);
  
  // Update collection cover if it's the first image
  const collection = data.collections.find(c => c.id === image.collectionId);
  if (collection && !collection.coverImage) {
    collection.coverImage = image.filePath;
    collection.updatedAt = new Date().toISOString();
  }
  
  writeData(data);
  return newImage;
}

export function updateImage(id: string, updates: Partial<WorkImage>): WorkImage | null {
  const data = readData();
  const index = data.images.findIndex(img => img.id === id);
  if (index === -1) return null;
  
  data.images[index] = {
    ...data.images[index],
    ...updates
  };
  writeData(data);
  return data.images[index];
}

export function deleteImage(id: string): boolean {
  const data = readData();
  const image = data.images.find(img => img.id === id);
  
  if (!image) return false;
  
  // Delete file from filesystem
  const filePath = path.join(process.cwd(), 'public', image.filePath);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
  
  data.images = data.images.filter(img => img.id !== id);
  writeData(data);
  return true;
}

// Config operations
export function getConfig(): SiteConfig {
  const data = readData();
  return data.config;
}

export function updateConfig(updates: Partial<SiteConfig>): SiteConfig {
  const data = readData();
  data.config = { ...data.config, ...updates };
  writeData(data);
  return data.config;
}

// Export all data as JSON
export function exportAllData(): SiteData {
  return readData();
}

// Get uploads directory
export function getUploadsDir(): string {
  ensureDirectories();
  return UPLOADS_DIR;
}
