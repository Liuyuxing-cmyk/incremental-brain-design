import { cookies } from 'next/headers';
import bcrypt from 'bcryptjs';
import { getConfig } from './data';

const AUTH_COOKIE_NAME = 'admin_auth';
const AUTH_COOKIE_VALUE = 'authenticated_admin_session';

// Simple password hash for default - in production use proper env variable
const DEFAULT_PASSWORD_HASH = '$2a$10$KBdGxHqQqK8pV6YJQn5yKuJCv5p7Qf5w5K5H5J5K5J5K5H5J5K5H'; // password: admin123

export async function verifyPassword(password: string): Promise<boolean> {
  try {
    const config = getConfig();
    if (!config.adminPassword) {
      // No password set, use default
      return password === 'admin123';
    }
    return await bcrypt.compare(password, config.adminPassword);
  } catch {
    // Fallback for demo mode
    return password === 'admin123';
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export function setAuthCookie(): void {
  const cookieStore = cookies();
  cookieStore.set(AUTH_COOKIE_NAME, AUTH_COOKIE_VALUE, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: '/',
  });
}

export function clearAuthCookie(): void {
  const cookieStore = cookies();
  cookieStore.delete(AUTH_COOKIE_NAME);
}

export function getAuthCookie(): string | undefined {
  const cookieStore = cookies();
  return cookieStore.get(AUTH_COOKIE_NAME)?.value;
}

export function isAuthenticated(): boolean {
  const cookie = getAuthCookie();
  return cookie === AUTH_COOKIE_VALUE;
}

export async function requireAuth(): Promise<{ authorized: boolean; error?: string }> {
  if (!isAuthenticated()) {
    return { authorized: false, error: 'Unauthorized' };
  }
  return { authorized: true };
}
