'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import Image from 'next/image';
import { useToast } from '@/components/ui/Toast';
import { useRouter } from 'next/navigation';

interface Collection {
  id: string;
  name: string;
  imageCount: number;
}

interface UploadedImage {
  id: string;
  filePath: string;
  themeName: string;
  originalName: string;
  status: 'uploading' | 'success' | 'error';
}

export default function UploadPage() {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [selectedCollection, setSelectedCollection] = useState('');
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [editThemeName, setEditThemeName] = useState<string | null>(null);
  const [themeNameInput, setThemeNameInput] = useState('');
  const [collectionImages, setCollectionImages] = useState<UploadedImage[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showToast } = useToast();
  const router = useRouter();

  useEffect(() => {
    fetch('/api/collections')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.data.length > 0) {
          setCollections(data.data);
          setSelectedCollection(data.data[0].id);
        }
      })
      .catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedCollection) {
      fetch(`/api/images?collectionId=${selectedCollection}`)
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            setCollectionImages(data.data.map((img: any) => ({
              ...img,
              status: 'success' as const
            })));
          }
        })
        .catch(console.error);
    }
  }, [selectedCollection]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, [selectedCollection]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  }, [selectedCollection]);

  const handleFiles = async (files: File[]) => {
    if (!selectedCollection) {
      showToast('请先选择一个作品集', 'error');
      return;
    }

    const imageFiles = files.filter(file => 
      file.type.startsWith('image/') || 
      ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].some(ext => 
        file.name.toLowerCase().endsWith(ext)
      )
    );

    if (imageFiles.length === 0) {
      showToast('请选择图片文件', 'error');
      return;
    }

    setUploading(true);

    const formData = new FormData();
    imageFiles.forEach(file => formData.append('files', file));
    formData.append('collectionId', selectedCollection);

    try {
      const res = await fetch('/api/images', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      if (data.success) {
        const newImages = data.data.map((img: any) => ({
          ...img,
          status: 'success' as const
        }));
        setCollectionImages(prev => [...newImages, ...prev]);
        showToast(`成功上传 ${newImages.length} 张图片`, 'success');
      } else {
        showToast(data.error || '上传失败', 'error');
      }
    } catch {
      showToast('上传失败，请重试', 'error');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleUpdateThemeName = async (id: string) => {
    if (!themeNameInput.trim()) {
      showToast('请输入主题名称', 'error');
      return;
    }

    try {
      const res = await fetch(`/api/images/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ themeName: themeNameInput.trim() })
      });

      const data = await res.json();

      if (data.success) {
        setCollectionImages(prev => 
          prev.map(img => img.id === id ? { ...img, themeName: themeNameInput.trim() } : img)
        );
        showToast('主题名称已更新', 'success');
      } else {
        showToast(data.error || '更新失败', 'error');
      }
    } catch {
      showToast('更新失败，请重试', 'error');
    }

    setEditThemeName(null);
    setThemeNameInput('');
  };

  const handleDeleteImage = async (id: string) => {
    try {
      const res = await fetch(`/api/images/${id}`, { method: 'DELETE' });
      const data = await res.json();

      if (data.success) {
        setCollectionImages(prev => prev.filter(img => img.id !== id));
        showToast('图片已删除', 'success');
      } else {
        showToast(data.error || '删除失败', 'error');
      }
    } catch {
      showToast('删除失败，请重试', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">上传图片</h1>
          <p className="text-gray-500 mt-1">批量上传设计作品图片，设置主题名称</p>
        </div>
        
        {/* Collection Selector */}
        <div className="flex items-center gap-3">
          <label className="text-sm text-gray-600">上传到：</label>
          <select
            value={selectedCollection}
            onChange={(e) => setSelectedCollection(e.target.value)}
            className="px-4 py-2 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white min-w-[200px]"
          >
            {collections.length > 0 ? (
              collections.map(col => (
                <option key={col.id} value={col.id}>{col.name}</option>
              ))
            ) : (
              <option value="">请先创建作品集</option>
            )}
          </select>
        </div>
      </div>

      {/* No Collections Notice */}
      {collections.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <div>
            <p className="text-sm text-amber-800 font-medium">暂无作品集</p>
            <p className="text-sm text-amber-700 mt-0.5">
              请先{' '}
              <button 
                onClick={() => router.push('/admin/collections')}
                className="underline hover:no-underline"
              >
                创建作品集
              </button>
              {' '}后再上传图片
            </p>
          </div>
        </div>
      )}

      {/* Upload Area */}
      <div
        className={`
          relative border-2 border-dashed rounded-2xl p-12 text-center transition-all
          ${dragging ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}
          ${uploading ? 'pointer-events-none opacity-60' : 'cursor-pointer'}
          ${collections.length === 0 ? 'opacity-50 pointer-events-none' : ''}
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={handleFileSelect}
        />
        
        {uploading ? (
          <div className="flex flex-col items-center">
            <svg className="w-12 h-12 text-blue-500 animate-spin mb-4" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <p className="text-gray-600 font-medium">上传中...</p>
          </div>
        ) : (
          <>
            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-gray-900 font-medium mb-1">
              拖拽图片到这里，或<span className="text-blue-600">点击选择文件</span>
            </p>
            <p className="text-sm text-gray-500">
              支持 JPG、PNG、GIF、WebP 格式，单文件最大 10MB
            </p>
          </>
        )}
      </div>

      {/* Tips */}
      <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
        <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div className="text-sm text-blue-800">
          <strong>使用提示：</strong>上传图片后，可点击图片下方的编辑按钮设置「主题命名/项目名称」，方便汇报时一键复制使用。
        </div>
      </div>

      {/* Images Grid */}
      {selectedCollection && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              已上传图片
              <span className="ml-2 text-sm font-normal text-gray-400">
                ({collectionImages.length} 张)
              </span>
            </h2>
          </div>

          {collectionImages.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {collectionImages.map(image => (
                <div 
                  key={image.id} 
                  className="group bg-white rounded-xl border border-gray-100 overflow-hidden hover:border-gray-200 hover:shadow-md transition-all"
                >
                  {/* Image */}
                  <div className="relative aspect-square bg-gray-100">
                    <Image
                      src={image.filePath}
                      alt={image.themeName}
                      fill
                      className="object-cover"
                    />
                    
                    {/* Delete Button */}
                    <button
                      onClick={() => handleDeleteImage(image.id)}
                      className="absolute top-2 right-2 p-1.5 bg-white/90 text-gray-500 hover:text-red-600 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>

                  {/* Info */}
                  <div className="p-3">
                    {editThemeName === image.id ? (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={themeNameInput}
                          onChange={(e) => setThemeNameInput(e.target.value)}
                          placeholder="输入主题名称"
                          className="flex-1 px-2 py-1 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleUpdateThemeName(image.id);
                            if (e.key === 'Escape') {
                              setEditThemeName(null);
                              setThemeNameInput('');
                            }
                          }}
                        />
                        <button
                          onClick={() => handleUpdateThemeName(image.id)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between gap-2">
                        <p 
                          className="text-sm text-gray-700 truncate flex-1 cursor-pointer hover:text-blue-600"
                          onClick={() => {
                            setEditThemeName(image.id);
                            setThemeNameInput(image.themeName);
                          }}
                          title="点击编辑"
                        >
                          {image.themeName}
                        </p>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(image.themeName);
                            showToast('已复制到剪贴板', 'success');
                          }}
                          className="p-1 text-gray-400 hover:text-gray-600 rounded"
                          title="复制名称"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                          </svg>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-100 p-12 text-center">
              <svg className="w-12 h-12 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p className="text-gray-500">该作品集暂无图片</p>
              <p className="text-sm text-gray-400 mt-1">点击上方区域上传图片</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
