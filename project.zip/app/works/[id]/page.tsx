'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import ImageCard from '@/components/gallery/ImageCard';
import Lightbox from '@/components/gallery/Lightbox';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

interface WorkImage {
  id: string;
  filePath: string;
  themeName: string;
}

interface Collection {
  id: string;
  name: string;
  description?: string;
}

export default function CollectionPage() {
  const params = useParams();
  const collectionId = params.id as string;
  
  const [collection, setCollection] = useState<Collection | null>(null);
  const [images, setImages] = useState<WorkImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  useEffect(() => {
    Promise.all([
      fetch(`/api/collections/${collectionId}`).then(res => res.json()),
      fetch(`/api/images?collectionId=${collectionId}`).then(res => res.json())
    ])
    .then(([collectionData, imagesData]) => {
      if (collectionData.success) {
        setCollection(collectionData.data);
      }
      if (imagesData.success) {
        setImages(imagesData.data);
      }
    })
    .catch(console.error)
    .finally(() => setLoading(false));
  }, [collectionId]);

  const openLightbox = (index: number) => {
    setLightboxIndex(index);
    setLightboxOpen(true);
  };

  const closeLightbox = () => setLightboxOpen(false);
  const prevImage = () => setLightboxIndex(prev => Math.max(0, prev - 1));
  const nextImage = () => setLightboxIndex(prev => Math.min(images.length - 1, prev + 1));

  const lightboxImages = images.map(img => ({
    id: img.id,
    src: img.filePath,
    themeName: img.themeName
  }));

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-1 pt-20">
        {/* Collection Header */}
        <section className="bg-white border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <Link 
              href="/"
              className="inline-flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              返回首页
            </Link>
            
            {loading ? (
              <div className="animate-pulse">
                <div className="h-10 bg-gray-200 rounded w-64 mb-3" />
                <div className="h-5 bg-gray-100 rounded w-96" />
              </div>
            ) : collection ? (
              <>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
                  {collection.name}
                </h1>
                {collection.description && (
                  <p className="text-gray-600 text-lg max-w-2xl">
                    {collection.description}
                  </p>
                )}
                <div className="mt-4 text-sm text-gray-400">
                  {images.length} 张作品
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">作品集不存在</p>
                <Link href="/" className="text-blue-600 hover:underline mt-2 inline-block">
                  返回首页
                </Link>
              </div>
            )}
          </div>
        </section>

        {/* Images Grid */}
        <section className="max-w-7xl mx-auto px-6 py-12">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="aspect-[4/3] bg-gray-200 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : images.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {images.map((image, index) => (
                <ImageCard
                  key={image.id}
                  id={image.id}
                  src={image.filePath}
                  themeName={image.themeName}
                  onClick={() => openLightbox(index)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-100">
              <div className="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">暂无作品</h3>
              <p className="text-gray-500 mb-6">该作品集还没有上传任何图片</p>
              <Link 
                href="/admin"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                上传作品
              </Link>
            </div>
          )}
        </section>

        {/* Tip */}
        {images.length > 0 && (
          <div className="max-w-7xl mx-auto px-6 pb-12">
            <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
              <svg className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div className="text-sm text-blue-800">
                <strong>使用提示：</strong>点击图片可查看大图，悬浮时显示作品名称，点击复制按钮可一键复制名称，方便汇报记录使用。
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />

      {/* Lightbox */}
      {lightboxOpen && images.length > 0 && (
        <Lightbox
          images={lightboxImages}
          currentIndex={lightboxIndex}
          onClose={closeLightbox}
          onPrev={prevImage}
          onNext={nextImage}
        />
      )}
    </div>
  );
}
