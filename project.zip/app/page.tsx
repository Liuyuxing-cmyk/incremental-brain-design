'use client';

import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import CollectionCard from '@/components/gallery/CollectionCard';
import Link from 'next/link';
import { useEffect, useState } from 'react';

interface Collection {
  id: string;
  name: string;
  description?: string;
  coverImage: string;
  imageCount: number;
}

export default function HomePage() {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [config, setConfig] = useState({ title: '增量大脑设计部', slogan: '用设计驱动增长，以作品证明实力' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/collections').then(res => res.json()),
      fetch('/api/images').then(res => res.json()),
      fetch('/api/config').then(res => res.json())
    ])
    .then(([collectionsData, imagesData, configData]) => {
      if (collectionsData.success && imagesData.success) {
        // Count images per collection
        const imageCountMap: Record<string, number> = {};
        imagesData.data.forEach((img: any) => {
          imageCountMap[img.collectionId] = (imageCountMap[img.collectionId] || 0) + 1;
        });
        
        // Attach cover image from first image if no cover set
        const collectionsWithData = collectionsData.data.map((col: any) => ({
          ...col,
          imageCount: imageCountMap[col.id] || 0,
          coverImage: col.coverImage || (imagesData.data.find((img: any) => img.collectionId === col.id)?.filePath || '')
        }));
        
        setCollections(collectionsWithData);
      }
      
      if (configData.success) {
        setConfig(configData.data);
      }
    })
    .catch(console.error)
    .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-b from-white to-neutral-50">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-100 rounded-full opacity-50 blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-100 rounded-full opacity-50 blur-3xl" />
          </div>
          
          <div className="relative max-w-7xl mx-auto px-6 py-24 md:py-32">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 tracking-tight">
                {config.title}
              </h1>
              <p className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed">
                {config.slogan}
              </p>
              
              {collections.length > 0 && (
                <a 
                  href="#collections"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/25"
                >
                  <span>浏览作品集</span>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                </a>
              )}
            </div>
          </div>
        </section>

        {/* Collections Grid */}
        <section id="collections" className="max-w-7xl mx-auto px-6 py-16 md:py-24">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">作品集</h2>
              <p className="text-gray-500">精选设计作品，呈现专业实力</p>
            </div>
            <span className="text-sm text-gray-400">{collections.length} 个作品集</span>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="bg-white rounded-2xl overflow-hidden border border-gray-100">
                  <div className="aspect-[4/3] bg-gray-200 animate-pulse" />
                  <div className="p-5">
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-3 animate-pulse" />
                    <div className="h-4 bg-gray-100 rounded w-full mb-4 animate-pulse" />
                    <div className="h-4 bg-gray-100 rounded w-2/3 animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          ) : collections.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {collections.map(collection => (
                <CollectionCard
                  key={collection.id}
                  id={collection.id}
                  name={collection.name}
                  description={collection.description}
                  coverImage={collection.coverImage}
                  imageCount={collection.imageCount}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-100">
              <div className="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">暂无作品集</h3>
              <p className="text-gray-500 mb-6">点击下方按钮进入后台创建第一个作品集</p>
              <Link 
                href="/admin"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                创建作品集
              </Link>
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}
