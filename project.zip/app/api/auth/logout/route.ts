import { NextRequest, NextResponse } from 'next/server';
import { exportAllData } from '@/lib/data';
import { requireAuth } from '@/lib/auth';

// GET /api/auth/logout - Clear auth cookie
export async function POST() {
  try {
    const response = NextResponse.json({ 
      success: true, 
      message: '已退出登录' 
    });
    
    response.cookies.set('admin_auth', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 0,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Error during logout:', error);
    return NextResponse.json(
      { success: false, error: '退出登录失败' },
      { status: 500 }
    );
  }
}
