import { NextResponse } from 'next/server';

export async function GET() {
  const authCookie = require('next/headers').cookies().get('admin_auth');
  
  return NextResponse.json({
    authorized: authCookie?.value === 'authenticated_admin_session'
  });
}
