import { NextRequest, NextResponse } from 'next/server';
import { getConfig, updateConfig } from '@/lib/data';
import { requireAuth, hashPassword } from '@/lib/auth';

// GET /api/config - Get site config
export async function GET() {
  try {
    const config = getConfig();
    // Don't return hashed password
    const safeConfig = {
      title: config.title,
      slogan: config.slogan,
      hasPassword: !!config.adminPassword,
    };
    return NextResponse.json({ success: true, data: safeConfig });
  } catch (error) {
    console.error('Error fetching config:', error);
    return NextResponse.json(
      { success: false, error: '获取配置失败' },
      { status: 500 }
    );
  }
}

// PUT /api/config - Update site config
export async function PUT(request: NextRequest) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { title, slogan, adminPassword } = body;

    const updates: any = {};
    if (title !== undefined) updates.title = title.trim();
    if (slogan !== undefined) updates.slogan = slogan.trim();
    if (adminPassword !== undefined && adminPassword !== '') {
      updates.adminPassword = await hashPassword(adminPassword);
    }

    const updated = updateConfig(updates);

    return NextResponse.json({ 
      success: true, 
      data: {
        title: updated.title,
        slogan: updated.slogan,
        hasPassword: !!updated.adminPassword,
      }
    });
  } catch (error) {
    console.error('Error updating config:', error);
    return NextResponse.json(
      { success: false, error: '更新配置失败' },
      { status: 500 }
    );
  }
}
