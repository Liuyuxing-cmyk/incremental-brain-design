import { NextRequest, NextResponse } from 'next/server';
import { exportAllData } from '@/lib/data';
import { requireAuth } from '@/lib/auth';

// GET /api/export - Export all data as JSON
export async function GET() {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const data = exportAllData();

    // Create a downloadable JSON file
    const jsonContent = JSON.stringify(data, null, 2);
    const timestamp = new Date().toISOString().slice(0, 10);
    
    const response = new NextResponse(jsonContent, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="design-works-backup-${timestamp}.json"`,
      },
    });

    return response;
  } catch (error) {
    console.error('Error exporting data:', error);
    return NextResponse.json(
      { success: false, error: '导出数据失败' },
      { status: 500 }
    );
  }
}
