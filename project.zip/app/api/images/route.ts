import { NextRequest, NextResponse } from 'next/server';
import { getImages, createImage, getUploadsDir } from '@/lib/data';
import { requireAuth } from '@/lib/auth';
import { generateId, isImageFile } from '@/lib/utils';
import { writeFile } from 'fs/promises';
import path from 'path';

// GET /api/images - Get all images or filter by collection
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const collectionId = searchParams.get('collectionId') || undefined;
    
    const images = getImages(collectionId);
    return NextResponse.json({ success: true, data: images });
  } catch (error) {
    console.error('Error fetching images:', error);
    return NextResponse.json(
      { success: false, error: '获取图片列表失败' },
      { status: 500 }
    );
  }
}

// POST /api/images - Upload new images
export async function POST(request: NextRequest) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const files = formData.getAll('files') as File[];
    const collectionId = formData.get('collectionId') as string;

    if (!collectionId) {
      return NextResponse.json(
        { success: false, error: '请选择所属集合' },
        { status: 400 }
      );
    }

    if (files.length === 0) {
      return NextResponse.json(
        { success: false, error: '请选择要上传的图片' },
        { status: 400 }
      );
    }

    const uploadsDir = getUploadsDir();
    const uploadedImages = [];

    for (const file of files) {
      if (!isImageFile(file.name)) {
        continue; // Skip non-image files
      }

      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        continue; // Skip files larger than 10MB
      }

      const fileId = generateId();
      const ext = path.extname(file.name);
      const newFileName = `${fileId}${ext}`;
      const filePath = `/uploads/${newFileName}`;
      const fullPath = path.join(uploadsDir, newFileName);

      // Save file
      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);
      await writeFile(fullPath, buffer);

      // Get existing images count for sort order
      const existingImages = getImages(collectionId);

      const newImage = createImage({
        id: fileId,
        collectionId,
        fileName: newFileName,
        originalName: file.name,
        themeName: path.basename(file.name, ext), // Default theme name from filename
        filePath,
        sortOrder: existingImages.length + uploadedImages.length + 1,
      });

      uploadedImages.push(newImage);
    }

    return NextResponse.json({ 
      success: true, 
      data: uploadedImages,
      message: `成功上传 ${uploadedImages.length} 张图片`
    }, { status: 201 });
  } catch (error) {
    console.error('Error uploading images:', error);
    return NextResponse.json(
      { success: false, error: '上传图片失败' },
      { status: 500 }
    );
  }
}
