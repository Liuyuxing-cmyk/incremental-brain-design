import { NextRequest, NextResponse } from 'next/server';
import { getImageById, updateImage, deleteImage } from '@/lib/data';
import { requireAuth } from '@/lib/auth';

interface RouteParams {
  params: { id: string }
}

// GET /api/images/[id] - Get a single image
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const image = getImageById(params.id);
    
    if (!image) {
      return NextResponse.json(
        { success: false, error: '图片不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: image });
  } catch (error) {
    console.error('Error fetching image:', error);
    return NextResponse.json(
      { success: false, error: '获取图片信息失败' },
      { status: 500 }
    );
  }
}

// PUT /api/images/[id] - Update an image
export async function PUT(request: NextRequest, { params }: RouteParams) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { themeName, sortOrder } = body;

    const existingImage = getImageById(params.id);
    if (!existingImage) {
      return NextResponse.json(
        { success: false, error: '图片不存在' },
        { status: 404 }
      );
    }

    const updates: Partial<typeof existingImage> = {};
    if (themeName !== undefined) updates.themeName = themeName.trim();
    if (sortOrder !== undefined) updates.sortOrder = sortOrder;

    const updated = updateImage(params.id, updates);

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error('Error updating image:', error);
    return NextResponse.json(
      { success: false, error: '更新图片失败' },
      { status: 500 }
    );
  }
}

// DELETE /api/images/[id] - Delete an image
export async function DELETE(request: NextRequest, { params }: RouteParams) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const success = deleteImage(params.id);

    if (!success) {
      return NextResponse.json(
        { success: false, error: '图片不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, message: '图片已删除' });
  } catch (error) {
    console.error('Error deleting image:', error);
    return NextResponse.json(
      { success: false, error: '删除图片失败' },
      { status: 500 }
    );
  }
}
