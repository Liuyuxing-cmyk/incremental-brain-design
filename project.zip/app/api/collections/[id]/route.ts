import { NextRequest, NextResponse } from 'next/server';
import { getCollectionById, updateCollection, deleteCollection } from '@/lib/data';
import { requireAuth } from '@/lib/auth';

interface RouteParams {
  params: { id: string }
}

// GET /api/collections/[id] - Get a single collection
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const collection = getCollectionById(params.id);
    
    if (!collection) {
      return NextResponse.json(
        { success: false, error: '集合不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: collection });
  } catch (error) {
    console.error('Error fetching collection:', error);
    return NextResponse.json(
      { success: false, error: '获取集合信息失败' },
      { status: 500 }
    );
  }
}

// PUT /api/collections/[id] - Update a collection
export async function PUT(request: NextRequest, { params }: RouteParams) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, coverImage, sortOrder } = body;

    const existingCollection = getCollectionById(params.id);
    if (!existingCollection) {
      return NextResponse.json(
        { success: false, error: '集合不存在' },
        { status: 404 }
      );
    }

    const updates: Partial<typeof existingCollection> = {};
    if (name !== undefined) updates.name = name.trim();
    if (description !== undefined) updates.description = description.trim();
    if (coverImage !== undefined) updates.coverImage = coverImage;
    if (sortOrder !== undefined) updates.sortOrder = sortOrder;

    const updated = updateCollection(params.id, updates);

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error('Error updating collection:', error);
    return NextResponse.json(
      { success: false, error: '更新集合失败' },
      { status: 500 }
    );
  }
}

// DELETE /api/collections/[id] - Delete a collection
export async function DELETE(request: NextRequest, { params }: RouteParams) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const success = deleteCollection(params.id);

    if (!success) {
      return NextResponse.json(
        { success: false, error: '集合不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, message: '集合已删除' });
  } catch (error) {
    console.error('Error deleting collection:', error);
    return NextResponse.json(
      { success: false, error: '删除集合失败' },
      { status: 500 }
    );
  }
}
