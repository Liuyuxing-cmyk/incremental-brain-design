import { NextRequest, NextResponse } from 'next/server';
import { getCollections, createCollection, updateCollection, deleteCollection, Collection } from '@/lib/data';
import { requireAuth } from '@/lib/auth';
import { generateId } from '@/lib/utils';

// GET /api/collections - Get all collections
export async function GET() {
  try {
    const collections = getCollections();
    return NextResponse.json({ success: true, data: collections });
  } catch (error) {
    console.error('Error fetching collections:', error);
    return NextResponse.json(
      { success: false, error: '获取集合列表失败' },
      { status: 500 }
    );
  }
}

// POST /api/collections - Create a new collection
export async function POST(request: NextRequest) {
  try {
    const auth = await requireAuth();
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.error },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, coverImage } = body;

    if (!name || typeof name !== 'string' || name.trim() === '') {
      return NextResponse.json(
        { success: false, error: '集合名称不能为空' },
        { status: 400 }
      );
    }

    const collections = getCollections();
    const maxOrder = collections.length > 0 
      ? Math.max(...collections.map(c => c.sortOrder)) 
      : 0;

    const newCollection = createCollection({
      id: generateId(),
      name: name.trim(),
      description: description?.trim() || '',
      coverImage: coverImage || '',
      sortOrder: maxOrder + 1,
    });

    return NextResponse.json({ success: true, data: newCollection }, { status: 201 });
  } catch (error) {
    console.error('Error creating collection:', error);
    return NextResponse.json(
      { success: false, error: '创建集合失败' },
      { status: 500 }
    );
  }
}
