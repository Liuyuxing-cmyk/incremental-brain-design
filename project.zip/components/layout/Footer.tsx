export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} 增量大脑设计部. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-gray-400">
            <span>用设计驱动增长</span>
            <span className="w-1 h-1 bg-gray-300 rounded-full" />
            <span>以作品证明实力</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
